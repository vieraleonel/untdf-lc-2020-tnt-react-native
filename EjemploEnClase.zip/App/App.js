import React from 'react';
import { View, Text, SafeAreaView, Image } from 'react-native';
import Button from './Components/Button';
import avatar from './Images/avatar.jpeg';

const App2 = () => (
  <SafeAreaView style={{ backgroundColor: '#593EA9', flex: 1 }}>

    {/* HEADER */}
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 10, marginVertical: 20 }}>
      <Text style={{ marginRight: 5, color: 'white' }}>Barritas</Text>
      <Text style={{ flex: 1, marginRight: 5, color: 'white' }}>Profile</Text>
      <Text style={{ marginRight: 5, color: 'white' }}>Campanita</Text>
      <Text style={{ color: 'white' }}>Cesto</Text>
    </View>

    {/* CARD */}
    <View style={{ 
      flex: 1, 
      backgroundColor: 'white', 
      marginHorizontal: 20, 
      borderWidth: 1,
      borderRadius: 5, 
      borderColor: 'white',
      marginTop: 75,
      alignItems: 'center',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 5, 
    }}>

      <Image source={avatar} style={{width: 150, height: 150, borderRadius: 75, marginTop: -75}} />

      {/* BOTONES */}
      <View style={{flexDirection: 'row', marginTop: 10}}>
        <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'space-around' }}>
          <Button label="CONNECT" />
          <Button label="MESSAGE" backgroundColor="#172B4D" />
        </View>
      </View>

      {/* NUMEROS */}
      <View style={{flexDirection: 'row', marginTop: 10}}>
        <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'space-around', marginTop: 25 }}>
          <View style={{ alignItems: 'center' }}>
            <Text>2k</Text>
            <Text>Orders</Text>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Text>10</Text>
            <Text>Prhotos</Text>
          </View>
          <View style={{ alignItems: 'center' }}>
            <Text>89</Text>
            <Text>Comments</Text>
          </View>
        </View>
      </View>
      
    </View>
  </SafeAreaView>
);

export default App2;
